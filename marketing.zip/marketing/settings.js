module.exports = {
   cookieSecret: 'marketing',
   //数据库名称
   db: 'marketing',
   host: 'localhost'
};